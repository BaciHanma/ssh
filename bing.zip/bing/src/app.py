#!/usr/bin/env python3
import subprocess

from flask import Flask, request, render_template, redirect


app = Flask(__name__)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/flag', methods=['GET', 'POST'])
def ping():
    if request.method == 'POST':
        host = request.form.get('host')
        try:
            output = subprocess.check_output(['/bin/sh', '-c', host], timeout=5)
            return render_template('ping_result.html', data=output.decode('utf-8'))
        except subprocess.CalledProcessError:
            return render_template('ping_result.html', data=f'error when executing command: {host}')

    return render_template('ping.html')


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
